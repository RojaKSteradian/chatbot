import React from 'react'
import Service from '../components/Services'

const Services = () => {
  return (
    
      <Service/>
   
  )
}

export default Services
