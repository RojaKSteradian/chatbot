import React from "react";
import ChatSection from "../components/chat/ChatSection";

const Chat = () => {
  return (
    <React.Fragment>
      <ChatSection />
    </React.Fragment>
  );
};

export default Chat;
