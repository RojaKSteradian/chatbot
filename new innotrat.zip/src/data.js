export const popularCourse = [
    {
      id: 1,
      img: "./images/drones1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "Drones And UAV Design",
      link : "/course1",
      price : 2999,
    },
  
    {
      id: 2,
      img: "./images/electric1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "Electric Vehicle Design",
      link : "/course2",
      price : 2999,
    },
  
    {
      id: 3,
      img: "./images/iot1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "IOT/EMBEDDED and Hardware Security",
      link : "/course3",
      price : 2999,
    },
  
    {
      id: 4,
      img: "./images/robotic1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "Robotic Hardware",
      link : "/course4",
      price : 2999,
    },
  
    {
      id: 5,
      img: "./images/cyber1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "Cyber Security",
    },
  
    {
      id: 6,
      img: "./images/drones1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "Drones And UAV Design",
    },
  
    {
      id: 7,
      img: "./images/robotic1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "Robotic Hardware",
    },
  
    {
      id: 8,
      img: "./images/electric1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "Electric Vehicle Design",
    },
  
    {
      id: 8,
      img: "./images/electric1.jpg",
      desc: "Beauty can be defined as a trait in someone or something that attracts our attention and makes us want to learn more about it.",
      title: "Electric Vehicle Design",
    },
  ];
  